package com.company.projectportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectportalApplicationTests {

	@Test
	void contextLoads() {
	}

}
